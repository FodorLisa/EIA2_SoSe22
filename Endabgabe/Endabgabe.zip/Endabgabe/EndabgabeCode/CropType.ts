namespace GardenSimulator {
    export enum CropType {
        PUMPKIN,
        CARROT,
        RADISH,
        SALAD,
        CORN,
    }
}
